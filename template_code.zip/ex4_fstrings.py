
# The following code defines some variables.

name = "Colin"
animal = "catepillar"
category = "cake"
flavour = "chocolate"
launch_date = 1990
fat_g = 23.6
weight_g = 625
portions = 10

# For each question define the f-string
# then display it i.e.
#
# a1 = f"..."
# print(a1)



# Q1. "This is a _____ _____ in the shape of a ____."
# insert flavour, category and animal


# Q2. "It was launched in the year ____."


# Q3. "A single portion weighs ____g."


# Q4. "If you ate a whole cake on each 
#      one of your birthdays in the 35 years 
#      since it was launched you would have 
#      consumed a total mass of ____kg of cake."


# Q5. "It's percentage fat is ______%"
