# The following code defines some variables.
# You can to complete the type information
# choosing from int float or string

# The first question is completed for you
# as an example (a1 = 10 is stored as an int)

# q1 
a1 = 10
# write the data type into the string below: 
a1_type="int"

# q2
a2 = 2.3
# write the data type into the string below: 
a1_type=""

# q3
a3 = 'ninety-nine'
# write the data type into the string below: 
a3_type=""

# q4
a4 = 7.0
# write the data type into the string below: 
a4_type=""

# q5
a5 = 8/4
# write the data type into the string below: 
a5_type=""

# q6
a6 = "2 + 4.3"
# write the data type into the string below: 
a6_type=""