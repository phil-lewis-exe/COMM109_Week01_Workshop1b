# The following code defines some strings

s1 = "the wizard of oz"
s2 = "i am shouting!"
s3 = "ThIS CasE iS aLl MeSsed uP"
s4 = "\tHello\n\tWorld\n\t  \n"
s5 = "    Goodbyeeee!     "
s6a = "The Godfather"
s6b = "is a great film"

# q1
# Display string s1 with each word capitalised.


# q2
# Display string s2 in upper case.


# q3
# Display string s3 in lower case.


# q4 
# Display string s4 removing any trailing
# whitespace at the end of the string


# q5
# Display string s5 removing any whitespace
# at the start or end of the string


